﻿namespace EduSync.Api.DTOs
{
    public class DashboardDto
    {
    }
}
