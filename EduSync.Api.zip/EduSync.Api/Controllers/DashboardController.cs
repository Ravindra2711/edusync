﻿namespace EduSync.Api.Controllers
{
    public class DashboardController
    {
    }
}
